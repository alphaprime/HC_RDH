Thanks to Yu Hen Hu for his JPEg encoder ..

Steps to Run:

1. Run jpegdemo.m (encoder) by Yu Hen Hu
2. Run ijpegdemo.m (decoder) by Ravi Lakkundi (Me)

Again Thanks to Yu Hen Hu for his support.

~R