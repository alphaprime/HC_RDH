function x=idivq(x,q)
x =x.*q;